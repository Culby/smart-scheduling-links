# Home - v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://smart-scheduling-links.org/ImplementationGuide/fhir.ig | *Version*:0.1.0 |
| Draft as of 2026-02-23 | *Computable Name*:fhirig |

## Introduction

This is an unofficial FHIR Implementation Guide (IG) that will be used to capture design decisions and discussions from the January 2026 HL7 Connecatathon.

## Scope and Purpose

Implement the specification as outlined in https://github.com/Culby/smart-scheduling-links/blob/master/specification.md

