# fhir.ig#0.1.0: null

## Pages

* [Home](index.md)
* [Specification](specification.md)
* [Artifacts Summary](artifacts.md)
* [Change Log](change-log.md)

## Resources

### ValueSets

* [Appointment Type and Reasons](ValueSet-appointment-type-and-reasons-vs.md)

### Resource Profiles

* [SMART Location](StructureDefinition-smart-location.md)
* [SMART Practitioner](StructureDefinition-smart-practitioner.md)
* [SmartPractitionerRole](StructureDefinition-smart-practitionerRole.md)
* [SMART Schedule](StructureDefinition-smart-schedule.md)
* [SMART Slot](StructureDefinition-smart-slot.md)

### Extensions

* [Booking Deep Link](StructureDefinition-booking-deep-link.md)
* [Booking Phone](StructureDefinition-booking-phone.md)

### ImplementationGuides

* [fhirig](index.md)

### Examples

* [OpenClinTech Primary Clinic (Location)](Location-ExampleSMARTLocation-PrimaryClinic.md)
* [fd3c7a99-bb59-4fef-9f79-88d1f7275ca6 (Practitioner)](Practitioner-fd3c7a99-bb59-4fef-9f79-88d1f7275ca6.md)
* [slot-123 (Slot)](Slot-slot-123.md)
